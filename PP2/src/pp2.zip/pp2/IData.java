package pp2;

import java.util.ArrayList;

/**
 * Interfaz que define el contrato para cualquier sistema de almacenamiento de datos.
 * Desacopla la lógica de la aplicación (vistas) del almacenamiento (modelo).
 */
public interface IData {

    /** Busca un jugador por username y password. Usado para login. */
    Player getPlayer(String username, String password);
    
    /** Busca un jugador solo por su username. Usado para verificación. */
    Player getPlayerByUsername(String username);
    
    /** Añade un nuevo jugador al almacenamiento. */
    boolean addPlayer(Player newPlayer);
    
    /** Elimina un jugador basado en su username. */
    boolean deletePlayer(String username);
    
    /** Actualiza la contraseña de un jugador. */
    boolean updatePassword(String username, String newPassword);
    
    /** Añade un nuevo log de partida a un jugador. */
    void addLog(String username, String logEntry);
    
    /** Devuelve la lista completa de jugadores. */
    ArrayList<Player> getAllPlayers();
}