package pp2;

import java.util.ArrayList;

/**
 * Clase que modela a un jugador.
 * Almacena su nombre, password, puntos y logs de partidas.
 * (Este nombre ya es claro y no necesita cambiarse).
 */
public class Player {

    private String username;
    private String password;
    private int puntos;
    private ArrayList<String> gameLogs;

    public Player(String username, String password) {
        this.username = username;
        this.password = password;
        this.puntos = 0; // Todos empiezan con 0 puntos
        this.gameLogs = new ArrayList<>();
    }

    // --- Getters y Setters ---
    
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getPuntos() {
        return puntos;
    }

    public void addPuntos(int puntos) {
        this.puntos += puntos;
    }

    public ArrayList<String> getGameLogs() {
        return gameLogs;
    }

    public void addGameLog(String logEntry) {
        // Añade al principio para que el más reciente esté primero
        this.gameLogs.add(0, logEntry); 
    }
}