package pp2;

import java.util.ArrayList;

/**
 * Clase de utilidades con métodos estáticos para el juego.
 * Aquí colocamos nuestra segunda función recursiva.
 */
public class GameUtils {

    // --- FUNCIÓN RECURSIVA 2: Merge Sort (para Ranking) ---
    
    /**
     * Ordena una lista de jugadores por puntos (descendente) usando Merge Sort.
     * Función "wrapper" que inicia la recursión.
     * @param list La lista de jugadores a ordenar.
     */
    public static void mergeSortPlayersByPoints(ArrayList<Player> list) {
        int n = list.size();
        if (n < 2) {
            return; // Base Case: Lista de 0 o 1 ya está ordenada
        }
        
        // 1. Dividir
        int mid = n / 2;
        ArrayList<Player> left = new ArrayList<>(list.subList(0, mid));
        ArrayList<Player> right = new ArrayList<>(list.subList(mid, n));

        // 2. Conquistar (Pasos Recursivos)
        mergeSortPlayersByPoints(left);
        mergeSortPlayersByPoints(right);

        // 3. Combinar
        merge(list, left, right);
    }

    /**
     * Helper recursivo que combina dos sub-listas ordenadas.
     */
    private static void merge(ArrayList<Player> list, ArrayList<Player> left, ArrayList<Player> right) {
        int i = 0, j = 0, k = 0;
        
        // Compara elementos de left y right y los pone en la lista original
        // Ordena por puntos de MAYOR a MENOR
        while (i < left.size() && j < right.size()) {
            if (left.get(i).getPuntos() >= right.get(j).getPuntos()) { // >= para orden descendente
                list.set(k++, left.get(i++));
            } else {
                list.set(k++, right.get(j++));
            }
        }
        
      
        while (i < left.size()) {
            list.set(k++, left.get(i++));
        }
        
       
        while (j < right.size()) {
            list.set(k++, right.get(j++));
        }
    }
}