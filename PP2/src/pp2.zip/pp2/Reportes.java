package pp2;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.swing.*;

/**
 * Ventana de Reportes.
 * Modificada para usar StorageManager y el sort recursivo.
 */
public class Reportes extends JFrame {

    private JFrame menuPrincipalFrame;

    public Reportes(JFrame menuPrincipalFrame) {
        this.menuPrincipalFrame = menuPrincipalFrame;
        
        // ... (El resto de la UI: JTabbedPane, etc. sigue igual) ...
        setSize(600, 500);
        setTitle("Reportes - Vampire Wargame");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        JTabbedPane tabbedPane = new JTabbedPane();
        JPanel rankingPanel = new JPanel(new BorderLayout());
        JTextArea rankingArea = new JTextArea();
        rankingArea.setEditable(false);
        rankingArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        rankingArea.setBackground(new Color(20, 20, 20));
        rankingArea.setForeground(Color.GREEN);
        rankingArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Cargamos los datos del ranking (MODIFICADO)
        rankingArea.setText(getRankingData());
        
        rankingPanel.add(new JScrollPane(rankingArea), BorderLayout.CENTER);
        tabbedPane.addTab("1. Ranking de Jugadores", rankingPanel);
        JPanel logsPanel = new JPanel(new BorderLayout());
        JTextArea logsArea = new JTextArea();
        logsArea.setEditable(false);
        logsArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        logsArea.setBackground(new Color(20, 20, 20));
        logsArea.setForeground(Color.CYAN);
        logsArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Cargamos los logs del usuario (MODIFICADO)
        logsArea.setText(getMisLogsData());
        
        logsPanel.add(new JScrollPane(logsArea), BorderLayout.CENTER);
        tabbedPane.addTab("2. Log de Mis Últimos Partidos", logsPanel);
        add(tabbedPane, BorderLayout.CENTER);
        JButton btnVolver = new JButton("Volver al Menú");
        btnVolver.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnVolver.addActionListener(e -> {
            menuPrincipalFrame.setVisible(true);
            dispose();
        });
        add(btnVolver, BorderLayout.SOUTH);
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                menuPrincipalFrame.setVisible(true);
            }
        });

        setVisible(true);
    }

    /**
     * Genera el String para el reporte de Ranking.
     * (MODIFICADO para usar la función recursiva)
     */
    private String getRankingData() {
        StringBuilder sb = new StringBuilder();
        sb.append("--- RANKING DE JUGADORES ---\n\n");
        sb.append(String.format("%-10s %-20s %-10s\n", "POSICIÓN", "USERNAME", "PUNTOS"));
        sb.append("-------------------------------------------\n");

        // Obtenemos los jugadores desde el StorageManager
        ArrayList<Player> jugadoresOrdenados = new ArrayList<>(StorageManager.storage.getAllPlayers());
        
        // --- ¡USO DE LA FUNCIÓN RECURSIVA 2! ---
        GameUtils.mergeSortPlayersByPoints(jugadoresOrdenados);
        // ----------------------------------------
        
        // (Reemplaza a la línea anterior que era:)
        // jugadoresOrdenados.sort(Comparator.comparingInt(Player::getPuntos).reversed());

        int posicion = 1;
        for (Player p : jugadoresOrdenados) {
            sb.append(String.format("%-10s %-20s %-10d\n", 
                    posicion + ".", 
                    p.getUsername(), 
                    p.getPuntos()));
            posicion++;
        }
        
        sb.append("\n\n* Cada gane otorga 3 puntos.");
        return sb.toString();
    }

    /**
     * Genera el String para el reporte de Logs del usuario.
     * (MODIFICADO para usar StorageManager)
     */
    private String getMisLogsData() {
        StringBuilder sb = new StringBuilder();
        
        // Obtenemos al usuario logueado desde el StorageManager
        Player user = StorageManager.loggedInUser;
        
        if (user == null) {
            return "ERROR: No hay usuario logueado.";
        }
        
        sb.append("--- LOGS DE: " + user.getUsername() + " ---\n");
        sb.append("--- (Del más reciente al más viejo) ---\n\n");

        ArrayList<String> logs = user.getGameLogs();
        
        if (logs.isEmpty()) {
            sb.append("No has finalizado ningún partido todavía.");
            return sb.toString();
        }

        // Recorremos la lista AL REVÉS
        for (int i = logs.size() - 1; i >= 0; i--) {
            sb.append("• " + logs.get(i) + "\n");
        }
        
        return sb.toString();
    }
}