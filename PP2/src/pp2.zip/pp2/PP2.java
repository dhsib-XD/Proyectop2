/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pp2;

/**
 *
 * @author CarlosXl
 */
public class PP2 {
    public static void main(String[] args) {
        
         new inicio();
         
    }
    /**
     * @param args the command line arguments
     */
    
   
    
    
}
